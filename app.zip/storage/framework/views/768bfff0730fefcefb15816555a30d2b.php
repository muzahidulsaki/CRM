<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between">
            <div>
                <h2 class="font-bold text-2xl text-gray-800 leading-tight">
                    নতুন প্রজেক্ট সেটআপ (New Project)
                </h2>
                <p class="text-sm text-gray-500 mt-1">সেলস অর্ডারের সাথে সংযুক্ত করে প্রজেক্ট টিম ও অগ্রগতি শুরু করুন</p>
            </div>
            <a href="<?php echo e(route('projects.index')); ?>" class="inline-flex items-center px-4 py-2 bg-gray-100 text-gray-700 text-sm font-semibold rounded-lg hover:bg-gray-200 transition">
                <svg class="w-4 h-4 me-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
                তালিকায় ফিরে যান
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">

            <?php if($errors->any()): ?>
                <div class="mb-6 p-4 bg-rose-50 border-l-4 border-rose-500 text-rose-800 rounded-r-lg shadow-sm">
                    <div class="font-bold text-sm">ত্রুটি সংশোধন করুন:</div>
                    <ul class="mt-2 list-disc list-inside text-xs space-y-1">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('projects.store')); ?>" class="bg-white rounded-2xl border border-gray-200 shadow-sm p-6 sm:p-8 space-y-6">
                <?php echo csrf_field(); ?>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">

                    <!-- Order Selection -->
                    <div class="sm:col-span-2">
                        <label class="block text-sm font-semibold text-gray-700 mb-1">সেলস অর্ডার নির্বাচন করুন <span class="text-rose-500">*</span></label>
                        <select name="order_id" required class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                            <option value="">অর্ডার সিলেক্ট করুন</option>
                            <?php if($preselectedOrder): ?>
                                <option value="<?php echo e($preselectedOrder->id); ?>" selected>
                                    <?php echo e($preselectedOrder->order_code); ?> - <?php echo e($preselectedOrder->title); ?> (<?php echo e($preselectedOrder->customer?->name); ?>)
                                </option>
                            <?php endif; ?>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!$preselectedOrder || $preselectedOrder->id !== $ord->id): ?>
                                    <option value="<?php echo e($ord->id); ?>" <?php echo e(old('order_id') == $ord->id ? 'selected' : ''); ?>>
                                        <?php echo e($ord->order_code); ?> - <?php echo e($ord->title); ?> (<?php echo e($ord->customer?->name); ?>)
                                    </option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <p class="text-xs text-gray-500 mt-1">শুধুমাত্র যে সকল অর্ডারের প্রজেক্ট এখনও তৈরি হয়নি সেগুলো এখানে প্রদর্শিত হবে।</p>
                    </div>

                    <!-- Project Name -->
                    <div class="sm:col-span-2">
                        <label class="block text-sm font-semibold text-gray-700 mb-1">প্রজেক্টের নাম <span class="text-rose-500">*</span></label>
                        <input type="text" name="name" required value="<?php echo e(old('name', $preselectedOrder?->title)); ?>" placeholder="যেমন: ই-কমার্স ওয়েবসাইট ডেভেলপমেন্ট ও পেমেন্ট ইন্টিগ্রেশন"
                            class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                    </div>

                    <!-- Category -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">ক্যাটাগরি <span class="text-rose-500">*</span></label>
                        <select name="category" required class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                            <?php $__currentLoopData = $serviceCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cat); ?>" <?php echo e(old('category', $preselectedOrder?->service_category) == $cat ? 'selected' : ''); ?>>
                                    <?php echo e($cat); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Project Manager -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">প্রজেক্ট ম্যানেজার</label>
                        <select name="project_manager_id" class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                            <option value="">পিএম নির্বাচন করুন</option>
                            <?php $__currentLoopData = $projectManagers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pm->id); ?>" <?php echo e(old('project_manager_id', auth()->id()) == $pm->id ? 'selected' : ''); ?>>
                                    <?php echo e($pm->name); ?> (<?php echo e($pm->role->name ?? 'Staff'); ?>)
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Start Date -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">শুরুর তারিখ</label>
                        <input type="date" name="start_date" value="<?php echo e(old('start_date', date('Y-m-d'))); ?>"
                            class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                    </div>

                    <!-- Deadline -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">ডেডলাইন (Deadline)</label>
                        <input type="date" name="deadline" value="<?php echo e(old('deadline', $preselectedOrder?->expected_delivery_date?->format('Y-m-d'))); ?>"
                            class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                    </div>

                    <!-- Status -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">প্রাথমিক স্ট্যাটাস <span class="text-rose-500">*</span></label>
                        <select name="status" required class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                            <?php $__currentLoopData = ['Pending', 'Planning', 'In Development', 'In QA', 'Client Review', 'Completed', 'Delivered']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($st); ?>" <?php echo e(old('status', 'Planning') == $st ? 'selected' : ''); ?>><?php echo e($st); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Git Repo -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">Git Repository URL (ঐচ্ছিক)</label>
                        <input type="url" name="git_repository" value="<?php echo e(old('git_repository')); ?>" placeholder="https://github.com/projuktisheba/project"
                            class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                    </div>

                    <!-- Live URL -->
                    <div class="sm:col-span-2">
                        <label class="block text-sm font-semibold text-gray-700 mb-1">লাইভ প্রিভিউ / টেস্ট ইউআরএল (ঐচ্ছিক)</label>
                        <input type="url" name="live_url" value="<?php echo e(old('live_url')); ?>" placeholder="https://demo.projuktisheba.com/client-project"
                            class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                    </div>

                    <!-- Description -->
                    <div class="sm:col-span-2">
                        <label class="block text-sm font-semibold text-gray-700 mb-1">প্রজেক্ট স্কোপ ও বিবরণ</label>
                        <textarea name="description" rows="3" class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500"><?php echo e(old('description')); ?></textarea>
                    </div>

                </div>

                <div class="pt-4 border-t border-gray-100 flex items-center justify-end gap-3">
                    <a href="<?php echo e(route('projects.index')); ?>" class="px-5 py-2.5 bg-gray-100 text-gray-700 rounded-lg text-sm font-semibold hover:bg-gray-200 transition">
                        বাতিল
                    </a>
                    <button type="submit" class="px-6 py-2.5 bg-indigo-600 text-white rounded-lg text-sm font-semibold hover:bg-indigo-700 shadow-sm transition">
                        প্রজেক্ট তৈরি করুন
                    </button>
                </div>
            </form>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\AIUB\Language\Laravel\Projukti_Sheba\CRM\resources\views/projects/create.blade.php ENDPATH**/ ?>