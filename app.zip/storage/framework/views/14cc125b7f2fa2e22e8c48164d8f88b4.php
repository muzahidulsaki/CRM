<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
                <h2 class="font-bold text-2xl text-gray-800 leading-tight flex items-center gap-2">
                    <svg class="w-7 h-7 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                    কোটেশন ম্যানেজমেন্ট (Quotations)
                </h2>
                <p class="text-sm text-gray-500 mt-1">ক্লায়েন্টের জন্য প্রস্তাবিত মূল্য তালিকা ও ইনভয়েস ট্র্যাকিং</p>
            </div>
            <a href="<?php echo e(route('quotations.create')); ?>" class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-lg font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700 shadow-sm transition">
                <svg class="w-4 h-4 me-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                নতুন কোটেশন তৈরি
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">

            <!-- Alerts -->
            <?php if(session('success')): ?>
                <div class="p-4 bg-emerald-50 border-l-4 border-emerald-500 text-emerald-800 rounded-r-lg shadow-sm flex items-center justify-between">
                    <div class="flex items-center gap-2">
                        <svg class="w-5 h-5 text-emerald-600" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                        <span class="font-medium text-sm"><?php echo e(session('success')); ?></span>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Quotation Metrics -->
            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
                <div class="bg-white p-4 rounded-xl border border-gray-200 shadow-sm text-center">
                    <div class="text-xs font-semibold text-gray-500 uppercase">মোট কোটেশন</div>
                    <div class="text-2xl font-bold text-gray-900 mt-1"><?php echo e($metrics['total']); ?></div>
                </div>

                <div class="bg-white p-4 rounded-xl border border-gray-200 shadow-sm text-center">
                    <div class="text-xs font-semibold text-indigo-600 uppercase">ড্রাফট (Draft)</div>
                    <div class="text-2xl font-bold text-indigo-700 mt-1"><?php echo e($metrics['draft']); ?></div>
                </div>

                <div class="bg-white p-4 rounded-xl border border-gray-200 shadow-sm text-center">
                    <div class="text-xs font-semibold text-amber-600 uppercase">পাঠানো হয়েছে (Sent)</div>
                    <div class="text-2xl font-bold text-amber-700 mt-1"><?php echo e($metrics['sent']); ?></div>
                </div>

                <div class="bg-white p-4 rounded-xl border border-gray-200 shadow-sm text-center">
                    <div class="text-xs font-semibold text-emerald-600 uppercase">গৃহীত (Accepted)</div>
                    <div class="text-2xl font-bold text-emerald-700 mt-1"><?php echo e($metrics['accepted']); ?></div>
                </div>

                <div class="bg-emerald-50/70 p-4 rounded-xl border border-emerald-200 shadow-sm text-center col-span-2 sm:col-span-1">
                    <div class="text-xs font-semibold text-emerald-800 uppercase">গৃহীত কাজের মূল্য</div>
                    <div class="text-xl font-bold text-emerald-900 mt-1">৳<?php echo e(number_format($metrics['total_value'])); ?></div>
                </div>
            </div>

            <!-- Quotations Table -->
            <div class="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200 text-left text-sm">
                        <thead class="bg-gray-50 text-gray-500 font-semibold uppercase text-xs">
                            <tr>
                                <th class="py-3.5 px-4">কোটেশন কোড</th>
                                <th class="py-3.5 px-4">ক্লায়েন্ট / লিড</th>
                                <th class="py-3.5 px-4">তারিখ</th>
                                <th class="py-3.5 px-4">মেয়াদ</th>
                                <th class="py-3.5 px-4">মোট পরিমাণ (৳)</th>
                                <th class="py-3.5 px-4">স্ট্যাটাস</th>
                                <th class="py-3.5 px-4 text-right">অ্যাকশন</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            <?php $__empty_1 = true; $__currentLoopData = $quotations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quotation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="hover:bg-gray-50/60 transition">
                                    <td class="py-3.5 px-4">
                                        <a href="<?php echo e(route('quotations.show', $quotation)); ?>" class="font-bold text-indigo-600 hover:text-indigo-800">
                                            <?php echo e($quotation->quotation_code); ?>

                                        </a>
                                    </td>
                                    <td class="py-3.5 px-4">
                                        <?php if($quotation->customer): ?>
                                            <div class="font-medium text-gray-900"><?php echo e($quotation->customer->name); ?></div>
                                            <div class="text-xs text-emerald-700 font-semibold"><?php echo e($quotation->customer->customer_code); ?></div>
                                        <?php elseif($quotation->lead): ?>
                                            <div class="font-medium text-gray-900"><?php echo e($quotation->lead->name); ?></div>
                                            <div class="text-xs text-indigo-600"><?php echo e($quotation->lead->lead_code); ?></div>
                                        <?php else: ?>
                                            <span class="text-gray-400 italic">অনির্দিষ্ট</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-3.5 px-4 text-xs text-gray-600">
                                        <?php echo e($quotation->quotation_date->format('d M, Y')); ?>

                                    </td>
                                    <td class="py-3.5 px-4 text-xs text-gray-600">
                                        <?php echo e($quotation->valid_until ? $quotation->valid_until->format('d M, Y') : 'সীমাহীন'); ?>

                                    </td>
                                    <td class="py-3.5 px-4 font-bold text-gray-900">
                                        ৳<?php echo e(number_format($quotation->total_amount, 2)); ?>

                                    </td>
                                    <td class="py-3.5 px-4">
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold <?php echo e($quotation->status === 'Accepted' ? 'bg-emerald-100 text-emerald-800' : ($quotation->status === 'Rejected' ? 'bg-rose-100 text-rose-800' : 'bg-gray-100 text-gray-800')); ?>">
                                            <?php echo e($quotation->status); ?>

                                        </span>
                                    </td>
                                    <td class="py-3.5 px-4 text-right">
                                        <div class="flex items-center justify-end gap-2">
                                            <a href="<?php echo e(route('quotations.show', $quotation)); ?>" class="text-indigo-600 hover:text-indigo-800 font-semibold text-xs bg-indigo-50 px-2.5 py-1 rounded hover:bg-indigo-100 transition">
                                                প্রিন্ট / ভিউ
                                            </a>
                                            <a href="<?php echo e(route('quotations.edit', $quotation)); ?>" class="text-gray-500 hover:text-amber-600 p-1">
                                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center py-10 text-gray-400 text-xs">
                                        কোন কোটেশন পাওয়া যায়নি।
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if($quotations->hasPages()): ?>
                    <div class="px-6 py-4 border-t border-gray-100 bg-gray-50">
                        <?php echo e($quotations->links()); ?>

                    </div>
                <?php endif; ?>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\AIUB\Language\Laravel\Projukti_Sheba\CRM\resources\views/quotations/index.blade.php ENDPATH**/ ?>