<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between">
            <div>
                <h2 class="font-bold text-2xl text-gray-800 leading-tight flex items-center gap-2">
                    <a href="<?php echo e(route('leads.show', $lead)); ?>" class="text-gray-400 hover:text-gray-600 transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
                    </a>
                    লিড সম্পাদনা: <?php echo e($lead->lead_code); ?>

                </h2>
                <p class="text-sm text-gray-500 mt-0.5"><?php echo e($lead->name); ?> - <?php echo e($lead->company_name ?? 'ব্যক্তিগত'); ?></p>
            </div>
            <a href="<?php echo e(route('leads.show', $lead)); ?>" class="text-sm font-medium text-gray-600 hover:text-gray-900 bg-white px-3.5 py-2 border border-gray-300 rounded-lg shadow-sm">
                প্রোফাইলে ফিরে যান
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">

            <form method="POST" action="<?php echo e(route('leads.update', $lead)); ?>" class="space-y-6">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <!-- Section 1: Customer & Business Info -->
                <div class="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-4">
                    <h3 class="text-base font-bold text-gray-900 flex items-center gap-2 border-b pb-3">
                        <span class="w-7 h-7 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-sm">১</span>
                        ব্যক্তি ও প্রাতিষ্ঠানিক তথ্য
                    </h3>

                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">গ্রাহকের নাম <span class="text-rose-500">*</span></label>
                            <input type="text" name="name" value="<?php echo e(old('name', $lead->name)); ?>" required class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-rose-600 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">মোবাইল নম্বর <span class="text-rose-500">*</span></label>
                            <input type="text" name="phone" value="<?php echo e(old('phone', $lead->phone)); ?>" required class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-rose-600 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">হোয়াটসঅ্যাপ</label>
                            <input type="text" name="whatsapp" value="<?php echo e(old('whatsapp', $lead->whatsapp)); ?>" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">ইমেইল অ্যাড্রেস</label>
                            <input type="email" name="email" value="<?php echo e(old('email', $lead->email)); ?>" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">প্রতিষ্ঠানের নাম</label>
                            <input type="text" name="company_name" value="<?php echo e(old('company_name', $lead->company_name)); ?>" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">ব্যবসার ধরন</label>
                            <input type="text" name="business_type" value="<?php echo e(old('business_type', $lead->business_type)); ?>" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">ঠিকানা</label>
                            <input type="text" name="address" value="<?php echo e(old('address', $lead->address)); ?>" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">শহর / জেলা</label>
                            <input type="text" name="city" value="<?php echo e(old('city', $lead->city)); ?>" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">ওয়েবসাইট / পেজ</label>
                            <input type="text" name="website" value="<?php echo e(old('website', $lead->website)); ?>" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                        </div>
                    </div>
                </div>

                <!-- Section 2: Pipeline, Service & Budget -->
                <div class="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-4">
                    <h3 class="text-base font-bold text-gray-900 flex items-center gap-2 border-b pb-3">
                        <span class="w-7 h-7 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-sm">২</span>
                        পাইপলাইন স্ট্যাটাস ও সেলস প্যারামিটার
                    </h3>

                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                        <!-- Lead Status -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">লিড স্ট্যাটাস <span class="text-rose-500">*</span></label>
                            <select name="lead_status" required class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 font-semibold text-indigo-900 bg-indigo-50/30">
                                <?php $__currentLoopData = ['New', 'Contacted', 'Interested', 'Meeting/Demo', 'Proposal Sent', 'Negotiation', 'Won', 'Lost']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($st); ?>" <?php echo e(old('lead_status', $lead->lead_status) == $st ? 'selected' : ''); ?>><?php echo e($st); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Lead Temperature -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">লিড টেম্পারেচার <span class="text-rose-500">*</span></label>
                            <select name="lead_temperature" required class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 font-semibold">
                                <option value="Hot" class="text-rose-600" <?php echo e(old('lead_temperature', $lead->lead_temperature) == 'Hot' ? 'selected' : ''); ?>>🔥 Hot (খুব আগ্রহী)</option>
                                <option value="Warm" class="text-amber-600" <?php echo e(old('lead_temperature', $lead->lead_temperature) == 'Warm' ? 'selected' : ''); ?>>⚡ Warm (মাঝারি)</option>
                                <option value="Cold" class="text-sky-600" <?php echo e(old('lead_temperature', $lead->lead_temperature) == 'Cold' ? 'selected' : ''); ?>>❄️ Cold (কম আগ্রহী)</option>
                            </select>
                        </div>

                        <!-- Interested Service -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">আগ্রহী সার্ভিস <span class="text-rose-500">*</span></label>
                            <select name="interested_service" required class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                                <?php $__currentLoopData = $serviceCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cat); ?>" <?php echo e(old('interested_service', $lead->interested_service) == $cat ? 'selected' : ''); ?>><?php echo e($cat); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Lead Source -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">লিড সোর্স <span class="text-rose-500">*</span></label>
                            <select name="lead_source" required class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                                <?php $__currentLoopData = $leadSources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $src): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($src); ?>" <?php echo e(old('lead_source', $lead->lead_source) == $src ? 'selected' : ''); ?>><?php echo e($src); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Assigned To -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">দায়িত্বপ্রাপ্ত সেলস কর্মী</label>
                            <select name="assigned_to" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                                <option value="">অনির্ধারিত (Unassigned)</option>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>" <?php echo e(old('assigned_to', $lead->assigned_to) == $user->id ? 'selected' : ''); ?>><?php echo e($user->name); ?> (<?php echo e($user->role->name ?? 'User'); ?>)</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Budget -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">ক্লায়েন্টের বাজেট (৳)</label>
                            <input type="number" step="0.01" name="budget" value="<?php echo e(old('budget', $lead->budget)); ?>" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                        </div>

                        <!-- Discussed Amount -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">আলোচিত পরিমাণ (৳)</label>
                            <input type="number" step="0.01" name="discussed_amount" value="<?php echo e(old('discussed_amount', $lead->discussed_amount)); ?>" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                        </div>

                        <!-- Next Follow-up Date -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">পরবর্তী ফলো-আপ</label>
                            <input type="datetime-local" name="next_followup_date" value="<?php echo e(old('next_followup_date', $lead->next_followup_date?->format('Y-m-d\TH:i'))); ?>" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                        </div>
                    </div>

                    <!-- Lost Reason (if Lost) -->
                    <div>
                        <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">লিড বাতিলের কারণ (যদি বাতিল বা Lost হয়)</label>
                        <input type="text" name="lost_reason" value="<?php echo e(old('lost_reason', $lead->lost_reason)); ?>" placeholder="উদা: বাজেট স্বল্পতা, অন্য এজেন্সি পছন্দ করেছে, যোগাযোগ বন্ধ" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                    </div>

                    <!-- Notes -->
                    <div>
                        <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">নোট ও বিশেষ বিবরণ</label>
                        <textarea name="notes" rows="3" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"><?php echo e(old('notes', $lead->notes)); ?></textarea>
                    </div>
                </div>

                <!-- Submit Button -->
                <div class="flex items-center justify-end gap-3">
                    <a href="<?php echo e(route('leads.show', $lead)); ?>" class="px-5 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold rounded-lg text-sm transition">
                        বাতিল
                    </a>
                    <button type="submit" class="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-sm shadow-sm transition flex items-center gap-2">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                        আপডেট সংরক্ষণ করুন
                    </button>
                </div>
            </form>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\AIUB\Language\Laravel\Projukti_Sheba\CRM\resources\views/leads/edit.blade.php ENDPATH**/ ?>