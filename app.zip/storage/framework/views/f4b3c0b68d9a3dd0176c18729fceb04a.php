<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Roles & Permissions Management')); ?>

            </h2>
            <span class="text-sm text-gray-500">Configure role-based access for Projukti Sheba CRM</span>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <?php if(session('success')): ?>
                <div class="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg flex items-center gap-2">
                    <svg class="w-5 h-5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                    <span><?php echo e(session('success')); ?></span>
                </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                <!-- Role List Column -->
                <div class="md:col-span-1 space-y-2">
                    <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider px-2 mb-2">System Roles</h3>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="p-3 bg-white rounded-lg border border-gray-200 shadow-sm flex justify-between items-center hover:border-indigo-300 transition">
                            <div>
                                <h4 class="font-semibold text-gray-800 text-sm"><?php echo e($r->name); ?></h4>
                                <span class="text-xs text-gray-500"><?php echo e($r->users->count()); ?> active users</span>
                            </div>
                            <span class="px-2 py-0.5 text-xs rounded bg-gray-100 text-gray-600 font-mono"><?php echo e($r->slug); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Role Permissions Configurations -->
                <div class="md:col-span-3 space-y-6">
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                            <form method="POST" action="<?php echo e(route('roles.update', $role)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <div class="flex flex-col sm:flex-row justify-between sm:items-center pb-4 mb-4 border-b border-gray-100 gap-2">
                                    <div>
                                        <div class="flex items-center gap-2">
                                            <h3 class="text-lg font-bold text-gray-900"><?php echo e($role->name); ?></h3>
                                            <span class="px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-50 text-indigo-700 font-mono"><?php echo e($role->slug); ?></span>
                                        </div>
                                        <p class="text-xs text-gray-500 mt-0.5"><?php echo e($role->description); ?></p>
                                    </div>

                                    <?php if($role->slug === 'admin'): ?>
                                        <span class="text-xs font-semibold px-3 py-1 rounded bg-amber-50 text-amber-700 border border-amber-200">
                                            Admin has unrestricted full access
                                        </span>
                                    <?php else: ?>
                                        <button type="submit" class="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg shadow-sm transition">
                                            Save Changes
                                        </button>
                                    <?php endif; ?>
                                </div>

                                <div class="space-y-4">
                                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module => $modulePerms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="bg-gray-50 rounded-lg p-3 border border-gray-100">
                                                <h4 class="text-xs font-bold text-indigo-700 uppercase tracking-wider mb-2 border-b border-gray-200 pb-1">
                                                    <?php echo e(strtoupper($module)); ?> Module
                                                </h4>
                                                <div class="space-y-1.5">
                                                    <?php $__currentLoopData = $modulePerms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <label class="flex items-center text-xs text-gray-700 hover:text-gray-900 cursor-pointer">
                                                            <input type="checkbox" 
                                                                   name="permissions[]" 
                                                                   value="<?php echo e($perm->id); ?>"
                                                                   <?php echo e($role->slug === 'admin' || $role->permissions->contains('id', $perm->id) ? 'checked' : ''); ?>

                                                                   <?php echo e($role->slug === 'admin' ? 'disabled' : ''); ?>

                                                                   class="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500 w-3.5 h-3.5 me-2">
                                                            <span><?php echo e($perm->name); ?></span>
                                                        </label>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </form>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\AIUB\Language\Laravel\Projukti_Sheba\CRM\resources\views/roles/index.blade.php ENDPATH**/ ?>