<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
                <h2 class="font-bold text-2xl text-gray-800 leading-tight flex items-center gap-2">
                    <svg class="w-7 h-7 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    কাজের লগ ও আওয়ারলি ট্র্যাকিং (Worklogs)
                </h2>
                <p class="text-sm text-gray-500 mt-1">ডেভেলপার ও ডিজাইনারদের দৈনিক কাজের সময় ও বিলযোগ্য ঘণ্টার হিসাব</p>
            </div>
            <button type="button" onclick="document.getElementById('logFormContainer').classList.toggle('hidden')"
                class="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg font-semibold text-xs uppercase tracking-widest hover:bg-indigo-700 shadow-sm transition">
                <svg class="w-4 h-4 me-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                নতুন কাজের লগ যোগ করুন
            </button>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">

            <!-- Flash Alert -->
            <?php if(session('success')): ?>
                <div class="p-4 bg-emerald-50 border-l-4 border-emerald-500 text-emerald-800 rounded-r-lg shadow-sm flex items-center justify-between">
                    <div class="flex items-center gap-2">
                        <svg class="w-5 h-5 text-emerald-600" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                        <span class="font-medium text-sm"><?php echo e(session('success')); ?></span>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Metrics -->
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div class="bg-white p-4 rounded-xl border border-gray-200 shadow-sm text-center">
                    <div class="text-xs font-semibold text-gray-500 uppercase">মোট ব্যয়িত সময়</div>
                    <div class="text-2xl font-bold text-gray-900 mt-1">
                        <?php echo e(number_format($metrics['total_hours'], 1)); ?> <span class="text-xs font-normal text-gray-500">ঘণ্টা</span>
                    </div>
                </div>

                <div class="bg-white p-4 rounded-xl border border-indigo-200 bg-indigo-50/30 shadow-sm text-center">
                    <div class="text-xs font-semibold text-indigo-600 uppercase">অনুমোদিত সময়</div>
                    <div class="text-2xl font-bold text-indigo-700 mt-1">
                        <?php echo e(number_format($metrics['approved_hours'], 1)); ?> <span class="text-xs font-normal text-gray-500">ঘণ্টা</span>
                    </div>
                </div>

                <div class="bg-white p-4 rounded-xl border border-emerald-200 bg-emerald-50/30 shadow-sm text-center">
                    <div class="text-xs font-semibold text-emerald-600 uppercase">মোট বিলযোগ্য অর্থ</div>
                    <div class="text-2xl font-bold text-emerald-700 mt-1">৳<?php echo e(number_format($metrics['total_billable'])); ?></div>
                </div>
            </div>

            <!-- Collapsible Worklog Entry Form -->
            <div id="logFormContainer" class="hidden bg-white p-6 rounded-2xl border border-indigo-200 shadow-sm">
                <h3 class="font-bold text-base text-gray-900 mb-4 border-b pb-2">নতুন কাজের লগ এন্ট্রি</h3>
                <form method="POST" action="<?php echo e(route('worklogs.store')); ?>" class="space-y-4">
                    <?php echo csrf_field(); ?>
                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 mb-1">কর্মী <span class="text-rose-500">*</span></label>
                            <select name="employee_id" required class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                                <option value="">কর্মী সিলেক্ট করুন</option>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($emp->id); ?>">
                                        <?php echo e($emp->user->name); ?> (<?php echo e($emp->designation); ?>)
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-gray-700 mb-1">তারিখ <span class="text-rose-500">*</span></label>
                            <input type="date" name="log_date" required value="<?php echo e(date('Y-m-d')); ?>"
                                class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-gray-700 mb-1">কাজের সময় (ঘণ্টা) <span class="text-rose-500">*</span></label>
                            <input type="number" step="0.25" min="0.25" name="hours_worked" required placeholder="যেমন: 4.5"
                                class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-gray-700 mb-1">প্রজেক্ট (ঐচ্ছিক)</label>
                            <select name="project_id" class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                                <option value="">প্রজেক্ট নির্বাচন করুন</option>
                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($proj->id); ?>"><?php echo e($proj->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-gray-700 mb-1">টাস্ক (ঐচ্ছিক)</label>
                            <select name="task_id" class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                                <option value="">টাস্ক নির্বাচন করুন</option>
                                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tsk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tsk->id); ?>"><?php echo e($tsk->task_code); ?> - <?php echo e($tsk->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-gray-700 mb-1">ঘণ্টাপ্রতি রেট (৳, ঐচ্ছিক)</label>
                            <input type="number" step="0.01" name="hourly_rate" placeholder="ফাঁকা রাখলে কর্মীর প্রোফাইল রেট প্রযোজ্য"
                                class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                        </div>

                        <div class="sm:col-span-3">
                            <label class="block text-xs font-semibold text-gray-700 mb-1">কাজের সারসংক্ষেপ ও অগ্রগতি <span class="text-rose-500">*</span></label>
                            <textarea name="work_summary" rows="2" required placeholder="আজকে কোন কোন মডিউল বা বাগ নিয়ে কাজ করেছেন..."
                                class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500"></textarea>
                        </div>
                    </div>

                    <div class="flex items-center justify-end gap-2 pt-2">
                        <button type="button" onclick="document.getElementById('logFormContainer').classList.add('hidden')"
                            class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-xs font-semibold hover:bg-gray-200 transition">
                            বাতিল
                        </button>
                        <button type="submit" class="px-5 py-2 bg-indigo-600 text-white rounded-lg text-xs font-semibold hover:bg-indigo-700 transition">
                            লগ সংরক্ষণ করুন
                        </button>
                    </div>
                </form>
            </div>

            <!-- Worklogs Table -->
            <div class="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200 text-left text-sm">
                        <thead class="bg-gray-50 text-gray-500 font-semibold uppercase text-xs">
                            <tr>
                                <th class="py-3.5 px-4">তারিখ</th>
                                <th class="py-3.5 px-4">কর্মী</th>
                                <th class="py-3.5 px-4">কাজের সারসংক্ষেপ</th>
                                <th class="py-3.5 px-4">প্রজেক্ট ও টাস্ক</th>
                                <th class="py-3.5 px-4">ব্যয়িত সময়</th>
                                <th class="py-3.5 px-4">বিলযোগ্য অর্থ</th>
                                <th class="py-3.5 px-4">স্ট্যাটাস</th>
                                <th class="py-3.5 px-4 text-right">অ্যাকশন</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            <?php $__empty_1 = true; $__currentLoopData = $worklogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="hover:bg-gray-50/60 transition">
                                    <td class="py-3.5 px-4 text-xs text-gray-600">
                                        <?php echo e($log->log_date->format('d M, Y')); ?>

                                    </td>
                                    <td class="py-3.5 px-4">
                                        <div class="font-bold text-gray-900"><?php echo e($log->employee->user->name); ?></div>
                                        <div class="text-xs text-gray-400"><?php echo e($log->employee->designation); ?></div>
                                    </td>
                                    <td class="py-3.5 px-4 text-xs text-gray-800 max-w-xs">
                                        <?php echo e($log->work_summary); ?>

                                    </td>
                                    <td class="py-3.5 px-4 text-xs text-gray-600">
                                        <?php if($log->project): ?>
                                            <div>📁 <?php echo e($log->project->name); ?></div>
                                        <?php endif; ?>
                                        <?php if($log->task): ?>
                                            <div class="text-indigo-600 font-medium mt-0.5"><?php echo e($log->task->task_code); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-3.5 px-4 font-bold text-gray-900">
                                        <?php echo e($log->hours_worked); ?> ঘণ্টা
                                    </td>
                                    <td class="py-3.5 px-4 font-bold text-emerald-700">
                                        ৳<?php echo e(number_format($log->billable_amount, 2)); ?>

                                    </td>
                                    <td class="py-3.5 px-4">
                                        <span class="px-2 py-0.5 rounded text-xs font-semibold <?php echo e($log->status === 'Approved' ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-100 text-gray-800'); ?>">
                                            <?php echo e($log->status); ?>

                                        </span>
                                    </td>
                                    <td class="py-3.5 px-4 text-right">
                                        <?php if($log->status !== 'Approved'): ?>
                                            <form method="POST" action="<?php echo e(route('worklogs.approve', $log)); ?>" class="inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <button type="submit" class="px-2.5 py-1 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded text-xs font-semibold transition">
                                                    অনুমোদন
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" class="py-12 text-center text-gray-400">
                                        <div class="text-base font-medium">কোনো কাজের লগ পাওয়া যায়নি</div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if($worklogs->hasPages()): ?>
                    <div class="p-4 border-t border-gray-100">
                        <?php echo e($worklogs->links()); ?>

                    </div>
                <?php endif; ?>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\AIUB\Language\Laravel\Projukti_Sheba\CRM\resources\views/worklogs/index.blade.php ENDPATH**/ ?>