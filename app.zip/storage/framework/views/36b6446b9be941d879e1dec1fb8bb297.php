<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
                <h2 class="font-bold text-2xl text-gray-800 leading-tight flex items-center gap-2">
                    <svg class="w-7 h-7 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
                    প্রজেক্ট ডিরেক্টরি (Projects)
                </h2>
                <p class="text-sm text-gray-500 mt-1">চলমান সফটওয়্যার, ওয়েবসাইট ও ক্রিয়েটিভ প্রজেক্টসমূহের অগ্রগতি ট্র্যাকিং</p>
            </div>
            <div class="flex items-center gap-2">
                <a href="<?php echo e(route('tasks.kanban')); ?>" class="inline-flex items-center px-4 py-2 bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-lg font-semibold text-xs uppercase tracking-widest hover:bg-indigo-100 transition">
                    <svg class="w-4 h-4 me-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17V7m0 10a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h2a2 2 0 012 2m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 10V7m0 10a2 2 0 002 2h2a2 2 0 002-2V7a2 2 0 00-2-2h-2a2 2 0 00-2 2"/></svg>
                    কানবান বোর্ড
                </a>
                <a href="<?php echo e(route('projects.create')); ?>" class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-lg font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700 shadow-sm transition">
                    <svg class="w-4 h-4 me-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                    নতুন প্রজেক্ট
                </a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">

            <!-- Alerts -->
            <?php if(session('success')): ?>
                <div class="p-4 bg-emerald-50 border-l-4 border-emerald-500 text-emerald-800 rounded-r-lg shadow-sm flex items-center justify-between">
                    <div class="flex items-center gap-2">
                        <svg class="w-5 h-5 text-emerald-600" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                        <span class="font-medium text-sm"><?php echo e(session('success')); ?></span>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Metrics Cards -->
            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                <div class="bg-white p-4 rounded-xl border border-gray-200 shadow-sm text-center">
                    <div class="text-xs font-semibold text-gray-500 uppercase">মোট প্রজেক্ট</div>
                    <div class="text-2xl font-bold text-gray-900 mt-1"><?php echo e($metrics['total']); ?></div>
                </div>

                <div class="bg-white p-4 rounded-xl border border-blue-200 bg-blue-50/30 shadow-sm text-center">
                    <div class="text-xs font-semibold text-blue-600 uppercase">চলমান (Active)</div>
                    <div class="text-2xl font-bold text-blue-700 mt-1"><?php echo e($metrics['active']); ?></div>
                </div>

                <div class="bg-white p-4 rounded-xl border border-indigo-200 bg-indigo-50/30 shadow-sm text-center">
                    <div class="text-xs font-semibold text-indigo-600 uppercase">ডেভেলপমেন্টে</div>
                    <div class="text-2xl font-bold text-indigo-700 mt-1"><?php echo e($metrics['in_development']); ?></div>
                </div>

                <div class="bg-white p-4 rounded-xl border border-purple-200 bg-purple-50/30 shadow-sm text-center">
                    <div class="text-xs font-semibold text-purple-600 uppercase">কিউএ রিভিউতে</div>
                    <div class="text-2xl font-bold text-purple-700 mt-1"><?php echo e($metrics['in_qa']); ?></div>
                </div>

                <div class="bg-white p-4 rounded-xl border border-emerald-200 bg-emerald-50/30 shadow-sm text-center">
                    <div class="text-xs font-semibold text-emerald-600 uppercase">সম্পন্ন</div>
                    <div class="text-2xl font-bold text-emerald-700 mt-1"><?php echo e($metrics['completed']); ?></div>
                </div>

                <div class="bg-white p-4 rounded-xl border border-rose-200 bg-rose-50/30 shadow-sm text-center">
                    <div class="text-xs font-semibold text-rose-600 uppercase">বিলম্বিত (Delayed)</div>
                    <div class="text-2xl font-bold text-rose-700 mt-1"><?php echo e($metrics['delayed']); ?></div>
                </div>
            </div>

            <!-- Filters -->
            <div class="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm">
                <form method="GET" action="<?php echo e(route('projects.index')); ?>" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 items-end">
                    <div>
                        <label class="block text-xs font-medium text-gray-700 mb-1">অনুসন্ধান</label>
                        <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="প্রজেক্ট কোড, নাম, ক্লায়েন্ট..."
                            class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                    </div>

                    <div>
                        <label class="block text-xs font-medium text-gray-700 mb-1">ক্যাটাগরি</label>
                        <select name="category" class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                            <option value="">সকল ক্যাটাগরি</option>
                            <?php $__currentLoopData = $serviceCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cat); ?>" <?php echo e(request('category') == $cat ? 'selected' : ''); ?>><?php echo e($cat); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs font-medium text-gray-700 mb-1">প্রজেক্ট ম্যানেজার</label>
                        <select name="pm_id" class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                            <option value="">সকল ম্যানেজার</option>
                            <?php $__currentLoopData = $projectManagers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pm->id); ?>" <?php echo e(request('pm_id') == $pm->id ? 'selected' : ''); ?>><?php echo e($pm->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs font-medium text-gray-700 mb-1">স্ট্যাটাস</label>
                        <select name="status" class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                            <option value="">সকল স্ট্যাটাস</option>
                            <?php $__currentLoopData = ['Pending', 'Planning', 'In Development', 'In QA', 'Client Review', 'Completed', 'Delivered', 'Delayed', 'Cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($st); ?>" <?php echo e(request('status') == $st ? 'selected' : ''); ?>><?php echo e($st); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="flex items-center gap-2">
                        <button type="submit" class="flex-1 py-2 px-4 bg-gray-900 text-white rounded-lg text-sm font-semibold hover:bg-gray-800 transition">
                            ফিল্টার
                        </button>
                        <?php if(request()->anyFilled(['search', 'category', 'pm_id', 'status'])): ?>
                            <a href="<?php echo e(route('projects.index')); ?>" class="py-2 px-3 bg-gray-100 text-gray-600 rounded-lg text-sm font-medium hover:bg-gray-200 transition">
                                রিসেট
                            </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <!-- Projects Grid / Cards -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="bg-white rounded-2xl border border-gray-200 hover:border-indigo-300 shadow-sm hover:shadow-md transition p-5 flex flex-col justify-between space-y-4">
                        
                        <div>
                            <!-- Header & Status -->
                            <div class="flex items-start justify-between gap-2">
                                <span class="text-xs font-mono font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">
                                    <?php echo e($project->project_code); ?>

                                </span>
                                <?php
                                    $stClass = match($project->status) {
                                        'In Development' => 'bg-blue-50 text-blue-700 border-blue-200',
                                        'In QA' => 'bg-purple-50 text-purple-700 border-purple-200',
                                        'Client Review' => 'bg-amber-50 text-amber-700 border-amber-200',
                                        'Completed', 'Delivered' => 'bg-emerald-50 text-emerald-700 border-emerald-200',
                                        'Delayed', 'Cancelled' => 'bg-rose-50 text-rose-700 border-rose-200',
                                        default => 'bg-gray-50 text-gray-700 border-gray-200'
                                    };
                                ?>
                                <span class="px-2 py-0.5 rounded-full text-xs font-semibold border <?php echo e($stClass); ?>">
                                    <?php echo e($project->status); ?>

                                </span>
                            </div>

                            <!-- Title & Customer -->
                            <h3 class="font-bold text-gray-900 text-lg mt-2 line-clamp-1">
                                <a href="<?php echo e(route('projects.show', $project)); ?>" class="hover:text-indigo-600 transition">
                                    <?php echo e($project->name); ?>

                                </a>
                            </h3>
                            <div class="text-xs text-gray-500 mt-1 flex items-center gap-1.5">
                                <svg class="w-3.5 h-3.5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                                <span><?php echo e($project->customer?->name ?? 'ক্লায়েন্ট নাম নেই'); ?></span>
                                <span class="text-gray-300">•</span>
                                <span class="text-gray-600"><?php echo e($project->category); ?></span>
                            </div>
                        </div>

                        <!-- Progress Bar & Tasks -->
                        <div class="space-y-2 pt-2 border-t border-gray-100">
                            <div class="flex items-center justify-between text-xs">
                                <span class="font-medium text-gray-600">অগ্রগতি (Progress)</span>
                                <span class="font-bold text-indigo-600"><?php echo e($project->progress_percent); ?>%</span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                                <div class="bg-indigo-600 h-2 rounded-full transition-all duration-300" style="width: <?php echo e($project->progress_percent); ?>%"></div>
                            </div>
                            <div class="flex items-center justify-between text-xs text-gray-500 pt-1">
                                <span>মোট টাস্ক: <?php echo e($project->tasks->count()); ?> টি</span>
                                <span>সম্পন্ন: <?php echo e($project->tasks->whereIn('status', ['Checked', 'Delivered'])->count()); ?> টি</span>
                            </div>
                        </div>

                        <!-- Footer Info & Actions -->
                        <div class="pt-3 border-t border-gray-100 flex items-center justify-between text-xs">
                            <div class="text-gray-500">
                                <?php if($project->deadline): ?>
                                    <?php
                                        $isOverdue = $project->deadline->isPast() && !in_array($project->status, ['Completed', 'Delivered']);
                                    ?>
                                    <span class="<?php echo e($isOverdue ? 'text-rose-600 font-bold' : ''); ?>">
                                        ডেডলাইন: <?php echo e($project->deadline->format('d M, Y')); ?>

                                    </span>
                                <?php else: ?>
                                    <span>ডেডলাইন নেই</span>
                                <?php endif; ?>
                            </div>

                            <a href="<?php echo e(route('projects.show', $project)); ?>" class="inline-flex items-center font-bold text-indigo-600 hover:text-indigo-800">
                                ড্যাশবোর্ড &rarr;
                            </a>
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-span-full py-12 text-center text-gray-400 bg-white rounded-2xl border border-gray-200">
                        <svg class="w-12 h-12 mx-auto mb-3 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
                        <div class="text-base font-medium">কোনো প্রজেক্ট পাওয়া যায়নি</div>
                        <div class="text-sm mt-1">অর্ডার থেকে স্বয়ংক্রিয়ভাবে বা ম্যানুয়ালি নতুন প্রজেক্ট তৈরি করুন।</div>
                    </div>
                <?php endif; ?>
            </div>

            <?php if($projects->hasPages()): ?>
                <div class="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm">
                    <?php echo e($projects->links()); ?>

                </div>
            <?php endif; ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\AIUB\Language\Laravel\Projukti_Sheba\CRM\resources\views/projects/index.blade.php ENDPATH**/ ?>