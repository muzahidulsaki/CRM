<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between">
            <div>
                <h2 class="font-bold text-2xl text-gray-800 leading-tight">
                    অর্ডার সম্পাদনা: <?php echo e($order->order_code); ?>

                </h2>
                <p class="text-sm text-gray-500 mt-1">অর্ডারের তথ্য, মূল্য ও ডেলিভারি শিডিউল আপডেট</p>
            </div>
            <a href="<?php echo e(route('orders.show', $order)); ?>" class="inline-flex items-center px-4 py-2 bg-gray-100 text-gray-700 text-sm font-semibold rounded-lg hover:bg-gray-200 transition">
                <svg class="w-4 h-4 me-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
                অর্ডারে ফিরে যান
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">

            <?php if($errors->any()): ?>
                <div class="mb-6 p-4 bg-rose-50 border-l-4 border-rose-500 text-rose-800 rounded-r-lg shadow-sm">
                    <div class="font-bold text-sm">ত্রুটি সংশোধন করুন:</div>
                    <ul class="mt-2 list-disc list-inside text-xs space-y-1">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('orders.update', $order)); ?>" class="bg-white rounded-2xl border border-gray-200 shadow-sm p-6 sm:p-8 space-y-6">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">

                    <!-- Customer (read-only reference) -->
                    <div class="sm:col-span-2">
                        <label class="block text-sm font-semibold text-gray-700 mb-1">ক্লায়েন্ট</label>
                        <div class="p-3 bg-gray-50 border border-gray-200 rounded-lg text-sm text-gray-900 font-medium">
                            <?php echo e($order->customer?->name); ?> (<?php echo e($order->customer?->company_name ?? 'ব্যক্তিগত'); ?>) - <?php echo e($order->customer?->phone); ?>

                        </div>
                    </div>

                    <!-- Title -->
                    <div class="sm:col-span-2">
                        <label class="block text-sm font-semibold text-gray-700 mb-1">অর্ডারের নাম <span class="text-rose-500">*</span></label>
                        <input type="text" name="title" required value="<?php echo e(old('title', $order->title)); ?>"
                            class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                    </div>

                    <!-- Service Category -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">সার্ভিস ক্যাটাগরি <span class="text-rose-500">*</span></label>
                        <select name="service_category" required class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                            <?php $__currentLoopData = $serviceCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cat); ?>" <?php echo e(old('service_category', $order->service_category) == $cat ? 'selected' : ''); ?>>
                                    <?php echo e($cat); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Status -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">স্ট্যাটাস <span class="text-rose-500">*</span></label>
                        <select name="status" required class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                            <?php $__currentLoopData = ['Pending', 'Confirmed', 'Project Started', 'Working', 'Under Review', 'Completed', 'Delivered', 'Cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($st); ?>" <?php echo e(old('status', $order->status) == $st ? 'selected' : ''); ?>><?php echo e($st); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Total Amount -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">মোট চুক্তি মূল্য (৳) <span class="text-rose-500">*</span></label>
                        <input type="number" step="0.01" name="total_amount" id="total_amount" required
                            value="<?php echo e(old('total_amount', $order->total_amount)); ?>"
                            class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                    </div>

                    <!-- Paid Amount -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">পরিশোধিত পরিমাণ (৳)</label>
                        <input type="number" step="0.01" name="paid_amount" id="paid_amount"
                            value="<?php echo e(old('paid_amount', $order->paid_amount)); ?>"
                            class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                    </div>

                    <!-- Due Display -->
                    <div class="sm:col-span-2 p-3 bg-gray-50 rounded-xl flex items-center justify-between border border-gray-200">
                        <span class="text-sm font-medium text-gray-700">অবশিষ্ট বকেয়া (Due):</span>
                        <span id="due_amount_display" class="text-base font-bold text-rose-600">৳0.00</span>
                    </div>

                    <!-- Order Date -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">অর্ডার তারিখ <span class="text-rose-500">*</span></label>
                        <input type="date" name="order_date" required value="<?php echo e(old('order_date', $order->order_date?->format('Y-m-d'))); ?>"
                            class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                    </div>

                    <!-- Expected Delivery Date -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">সম্ভাব্য ডেলিভারি তারিখ</label>
                        <input type="date" name="expected_delivery_date" value="<?php echo e(old('expected_delivery_date', $order->expected_delivery_date?->format('Y-m-d'))); ?>"
                            class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                    </div>

                    <!-- PM -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">প্রজেক্ট ম্যানেজার</label>
                        <select name="project_manager_id" class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                            <option value="">নির্বাচন করুন</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>" <?php echo e(old('project_manager_id', $order->project_manager_id) == $user->id ? 'selected' : ''); ?>>
                                    <?php echo e($user->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Sales Person -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">সেলস কর্মী</label>
                        <select name="sales_person_id" class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                            <option value="">নির্বাচন করুন</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>" <?php echo e(old('sales_person_id', $order->sales_person_id) == $user->id ? 'selected' : ''); ?>>
                                    <?php echo e($user->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Notes -->
                    <div class="sm:col-span-2">
                        <label class="block text-sm font-semibold text-gray-700 mb-1">নোট / বিস্তারিত বিবরণ</label>
                        <textarea name="notes" rows="3" class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500"><?php echo e(old('notes', $order->notes)); ?></textarea>
                    </div>

                </div>

                <div class="pt-4 border-t border-gray-100 flex items-center justify-end gap-3">
                    <a href="<?php echo e(route('orders.show', $order)); ?>" class="px-5 py-2.5 bg-gray-100 text-gray-700 rounded-lg text-sm font-semibold hover:bg-gray-200 transition">
                        বাতিল
                    </a>
                    <button type="submit" class="px-6 py-2.5 bg-indigo-600 text-white rounded-lg text-sm font-semibold hover:bg-indigo-700 shadow-sm transition">
                        পরিবর্তন সংরক্ষণ করুন
                    </button>
                </div>
            </form>

        </div>
    </div>

    <script>
        function updateDue() {
            const total = parseFloat(document.getElementById('total_amount').value) || 0;
            const paid = parseFloat(document.getElementById('paid_amount').value) || 0;
            const due = Math.max(0, total - paid);
            document.getElementById('due_amount_display').innerText = '৳' + due.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
        }
        document.getElementById('total_amount').addEventListener('input', updateDue);
        document.getElementById('paid_amount').addEventListener('input', updateDue);
        updateDue();
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\AIUB\Language\Laravel\Projukti_Sheba\CRM\resources\views/orders/edit.blade.php ENDPATH**/ ?>