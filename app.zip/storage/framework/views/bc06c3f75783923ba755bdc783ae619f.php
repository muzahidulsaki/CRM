<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between">
            <div>
                <h2 class="font-bold text-2xl text-gray-800 leading-tight flex items-center gap-2">
                    <a href="<?php echo e(route('leads.index')); ?>" class="text-gray-400 hover:text-gray-600 transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
                    </a>
                    নতুন লিড এন্ট্রি (New Lead)
                </h2>
                <p class="text-sm text-gray-500 mt-0.5">নতুন গ্রাহক বা সম্ভাব্য প্রজেক্টের বিস্তারিত তথ্য সংগ্রহ করুন</p>
            </div>
            <a href="<?php echo e(route('leads.index')); ?>" class="text-sm font-medium text-gray-600 hover:text-gray-900 bg-white px-3.5 py-2 border border-gray-300 rounded-lg shadow-sm">
                তালিকায় ফিরে যান
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">

            <!-- Duplicate Warning Card from Session -->
            <?php if(session('duplicate_warning')): ?>
                <?php $dup = session('duplicate_warning'); ?>
                <div class="mb-6 p-4 bg-amber-50 border-l-4 border-amber-500 rounded-r-xl shadow-sm">
                    <div class="flex items-start gap-3">
                        <svg class="w-6 h-6 text-amber-600 shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
                        <div class="flex-1">
                            <h3 class="text-sm font-bold text-amber-800">ডুপ্লিকেট লিড সনাক্ত হয়েছে!</h3>
                            <p class="text-sm text-amber-700 mt-1"><?php echo e($dup['message']); ?></p>
                            <div class="mt-3 flex items-center gap-3">
                                <?php if($dup['type'] === 'lead'): ?>
                                    <a href="<?php echo e(route('leads.show', $dup['record']->id)); ?>" target="_blank" class="inline-flex items-center text-xs font-semibold px-3 py-1.5 bg-amber-600 text-white rounded-md hover:bg-amber-700 transition">
                                        বিদ্যমান লিড দেখুন (<?php echo e($dup['record']->lead_code); ?>) &rarr;
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('customers.show', $dup['record']->id)); ?>" target="_blank" class="inline-flex items-center text-xs font-semibold px-3 py-1.5 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 transition">
                                        গ্রাহকের প্রোফাইল দেখুন (<?php echo e($dup['record']->customer_code); ?>) &rarr;
                                    </a>
                                <?php endif; ?>
                                <label class="inline-flex items-center gap-1.5 text-xs text-amber-900 font-medium cursor-pointer">
                                    <input type="checkbox" name="allow_duplicate" value="1" form="lead-form" class="rounded border-amber-300 text-amber-600 focus:ring-amber-500">
                                    <span>তবুও নতুন লিড তৈরি করতে বাধ্য করুন</span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Live Duplicate Alert Container (via AJAX) -->
            <div id="live-duplicate-alert" class="hidden mb-6 p-4 bg-rose-50 border-l-4 border-rose-500 rounded-r-xl shadow-sm">
                <div class="flex items-start gap-3">
                    <svg class="w-6 h-6 text-rose-600 shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    <div class="flex-1">
                        <h3 class="text-sm font-bold text-rose-800">সতর্কতা: ডুপ্লিকেট কন্ট্যাক্ট নম্বর!</h3>
                        <p id="live-duplicate-msg" class="text-sm text-rose-700 mt-1"></p>
                        <div class="mt-2" id="live-duplicate-link-container"></div>
                    </div>
                </div>
            </div>

            <form id="lead-form" method="POST" action="<?php echo e(route('leads.store')); ?>" class="space-y-6">
                <?php echo csrf_field(); ?>

                <!-- Section 1: Customer & Business Info -->
                <div class="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-4">
                    <h3 class="text-base font-bold text-gray-900 flex items-center gap-2 border-b pb-3">
                        <span class="w-7 h-7 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-sm">১</span>
                        ব্যক্তি ও প্রাতিষ্ঠানিক তথ্য
                    </h3>

                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        <!-- Name -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">গ্রাহকের নাম <span class="text-rose-500">*</span></label>
                            <input type="text" name="name" value="<?php echo e(old('name')); ?>" required placeholder="উদা: মোঃ আরিফুল ইসলাম" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-rose-600 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Phone -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">মোবাইল নম্বর <span class="text-rose-500">*</span></label>
                            <input type="text" id="phone" name="phone" value="<?php echo e(old('phone')); ?>" required placeholder="উদা: 017XXXXXXXX" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                            <span class="text-[11px] text-gray-400">ডুপ্লিকেট চেক সক্রিয় (+88 স্বয়ংক্রিয় নরম্যালাইজ হবে)</span>
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-rose-600 text-xs block"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- WhatsApp -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">হোয়াটসঅ্যাপ (যদি থাকে)</label>
                            <input type="text" id="whatsapp" name="whatsapp" value="<?php echo e(old('whatsapp')); ?>" placeholder="উদা: 018XXXXXXXX" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                        </div>

                        <!-- Email -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">ইমেইল অ্যাড্রেস</label>
                            <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="client@example.com" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                        </div>

                        <!-- Company Name -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">প্রতিষ্ঠানের নাম</label>
                            <input type="text" name="company_name" value="<?php echo e(old('company_name')); ?>" placeholder="উদা: টেকনোলজি বিডি লিমিটেড" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                        </div>

                        <!-- Business Type -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">ব্যবসার ধরন</label>
                            <input type="text" name="business_type" value="<?php echo e(old('business_type')); ?>" placeholder="উদা: রেস্টুরেন্ট, ই-কমার্স, এনজিও" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">ঠিকানা</label>
                            <input type="text" name="address" value="<?php echo e(old('address')); ?>" placeholder="বাড়ি/রোড/এরিয়া" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">শহর / জেলা</label>
                            <input type="text" name="city" value="<?php echo e(old('city', 'Dhaka')); ?>" placeholder="Dhaka, Chittagong, etc." class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">ওয়েবসাইট / ফেসবুক পেজ</label>
                            <input type="text" name="website" value="<?php echo e(old('website')); ?>" placeholder="https://..." class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                        </div>
                    </div>
                </div>

                <!-- Section 2: Service, Budget & Source -->
                <div class="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-4">
                    <h3 class="text-base font-bold text-gray-900 flex items-center gap-2 border-b pb-3">
                        <span class="w-7 h-7 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-sm">২</span>
                        সার্ভিস রিকোয়ারমেন্ট ও সেলস প্যারামিটার
                    </h3>

                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                        <!-- Lead Source -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">লিড সোর্স (Lead Source) <span class="text-rose-500">*</span></label>
                            <select name="lead_source" required class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                                <?php $__currentLoopData = $leadSources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $src): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($src); ?>" <?php echo e(old('lead_source') == $src ? 'selected' : ''); ?>><?php echo e($src); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Interested Service (8 categories) -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">আগ্রহী সার্ভিস <span class="text-rose-500">*</span></label>
                            <select name="interested_service" required class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                                <?php $__currentLoopData = $serviceCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cat); ?>" <?php echo e(old('interested_service') == $cat ? 'selected' : ''); ?>><?php echo e($cat); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Lead Temperature -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">লিড টেম্পারেচার <span class="text-rose-500">*</span></label>
                            <select name="lead_temperature" required class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 font-semibold">
                                <option value="Hot" class="text-rose-600" <?php echo e(old('lead_temperature') == 'Hot' ? 'selected' : ''); ?>>🔥 Hot (খুব আগ্রহী ও দ্রুত কাজ শুরু)</option>
                                <option value="Warm" class="text-amber-600" <?php echo e(old('lead_temperature', 'Warm') == 'Warm' ? 'selected' : ''); ?>>⚡ Warm (আগ্রহী কিন্তু সময় নিচ্ছে)</option>
                                <option value="Cold" class="text-sky-600" <?php echo e(old('lead_temperature') == 'Cold' ? 'selected' : ''); ?>>❄️ Cold (কম আগ্রহী / প্রাইস যাচাই)</option>
                            </select>
                        </div>

                        <!-- Assigned To -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">দায়িত্বপ্রাপ্ত সেলস কর্মী</label>
                            <select name="assigned_to" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                                <option value="">অনির্ধারিত (Unassigned)</option>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>" <?php echo e(old('assigned_to', auth()->id()) == $user->id ? 'selected' : ''); ?>><?php echo e($user->name); ?> (<?php echo e($user->role->name ?? 'User'); ?>)</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Budget -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">ক্লায়েন্টের সম্ভাব্য বাজেট (৳)</label>
                            <input type="number" step="0.01" name="budget" value="<?php echo e(old('budget')); ?>" placeholder="উদা: 25000" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                        </div>

                        <!-- Discussed Amount -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">আলোচিত টাকার পরিমাণ (৳)</label>
                            <input type="number" step="0.01" name="discussed_amount" value="<?php echo e(old('discussed_amount')); ?>" placeholder="উদা: 22000" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                        </div>

                        <!-- Next Follow-up Date -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">পরবর্তী যোগাযোগের সময়</label>
                            <input type="datetime-local" name="next_followup_date" value="<?php echo e(old('next_followup_date')); ?>" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                        </div>

                        <!-- Expected Work Date -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">কবে কাজ শুরু হতে পারে</label>
                            <input type="date" name="expected_work_date" value="<?php echo e(old('expected_work_date')); ?>" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                        </div>
                    </div>

                    <!-- Notes -->
                    <div class="pt-2">
                        <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">প্রাথমিক আলোচনার বিবরণ ও নোট</label>
                        <textarea name="notes" rows="3" placeholder="ক্লায়েন্টের চাহিদা, সফটওয়্যার বা ভিডিওর স্পেসিফিকেশন..." class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"><?php echo e(old('notes')); ?></textarea>
                    </div>
                </div>

                <!-- Submit Button -->
                <div class="flex items-center justify-end gap-3">
                    <a href="<?php echo e(route('leads.index')); ?>" class="px-5 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold rounded-lg text-sm transition">
                        বাতিল
                    </a>
                    <button type="submit" class="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-sm shadow-sm transition flex items-center gap-2">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                        লিড সংরক্ষণ করুন
                    </button>
                </div>
            </form>

        </div>
    </div>

    <!-- Live Duplicate Checking Script -->
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const phoneInput = document.getElementById('phone');
            const whatsappInput = document.getElementById('whatsapp');
            const emailInput = document.getElementById('email');
            const alertBox = document.getElementById('live-duplicate-alert');
            const msgBox = document.getElementById('live-duplicate-msg');
            const linkContainer = document.getElementById('live-duplicate-link-container');

            let timer = null;

            function checkDuplicates() {
                const phone = phoneInput.value.trim();
                const whatsapp = whatsappInput.value.trim();
                const email = emailInput.value.trim();

                if (phone.length < 5 && whatsapp.length < 5 && email.length < 5) {
                    alertBox.classList.add('hidden');
                    return;
                }

                fetch('<?php echo e(route('leads.check-duplicate')); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    },
                    body: JSON.stringify({ phone, whatsapp, email })
                })
                .then(res => res.json())
                .then(data => {
                    if (data.is_duplicate) {
                        msgBox.innerText = data.message;
                        if (data.type === 'lead') {
                            linkContainer.innerHTML = `<a href="/leads/${data.record.id}" target="_blank" class="inline-flex items-center text-xs font-semibold px-2.5 py-1 bg-rose-600 text-white rounded hover:bg-rose-700 transition">পূর্বের লিড দেখুন (${data.record.lead_code}) &rarr;</a>`;
                        } else if (data.type === 'customer') {
                            linkContainer.innerHTML = `<a href="/customers/${data.record.id}" target="_blank" class="inline-flex items-center text-xs font-semibold px-2.5 py-1 bg-emerald-600 text-white rounded hover:bg-emerald-700 transition">পূর্বের গ্রাহক প্রোফাইল দেখুন (${data.record.customer_code}) &rarr;</a>`;
                        }
                        alertBox.classList.remove('hidden');
                    } else {
                        alertBox.classList.add('hidden');
                    }
                })
                .catch(err => console.error('Duplicate check error:', err));
            }

            [phoneInput, whatsappInput, emailInput].forEach(el => {
                el.addEventListener('input', () => {
                    clearTimeout(timer);
                    timer = setTimeout(checkDuplicates, 500);
                });
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\AIUB\Language\Laravel\Projukti_Sheba\CRM\resources\views/leads/create.blade.php ENDPATH**/ ?>