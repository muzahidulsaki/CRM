<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
                <h2 class="font-bold text-2xl text-gray-800 leading-tight flex items-center gap-2">
                    <svg class="w-7 h-7 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/></svg>
                    টাস্ক ম্যানেজমেন্ট (Tasks)
                </h2>
                <p class="text-sm text-gray-500 mt-1">প্রজেক্ট অনুসারে টিম মেম্বারদের কাজের তালিকা ও কিউএ ট্র্যাকিং</p>
            </div>
            <div class="flex items-center gap-2">
                <a href="<?php echo e(route('tasks.kanban')); ?>" class="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg font-semibold text-xs uppercase tracking-widest hover:bg-indigo-700 shadow-sm transition">
                    <svg class="w-4 h-4 me-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17V7m0 10a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h2a2 2 0 012 2m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 10V7m0 10a2 2 0 002 2h2a2 2 0 002-2V7a2 2 0 00-2-2h-2a2 2 0 00-2 2"/></svg>
                    কানবান বোর্ডে দেখুন
                </a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">

            <!-- Flash Alert -->
            <?php if(session('success')): ?>
                <div class="p-4 bg-emerald-50 border-l-4 border-emerald-500 text-emerald-800 rounded-r-lg shadow-sm flex items-center justify-between">
                    <div class="flex items-center gap-2">
                        <svg class="w-5 h-5 text-emerald-600" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                        <span class="font-medium text-sm"><?php echo e(session('success')); ?></span>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Metrics -->
            <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
                <div class="bg-white p-3.5 rounded-xl border border-gray-200 shadow-sm text-center">
                    <div class="text-[11px] font-semibold text-gray-500 uppercase">মোট টাস্ক</div>
                    <div class="text-xl font-bold text-gray-900 mt-0.5"><?php echo e($metrics['total']); ?></div>
                </div>
                <div class="bg-white p-3.5 rounded-xl border border-gray-200 shadow-sm text-center">
                    <div class="text-[11px] font-semibold text-gray-500 uppercase">পেন্ডিং</div>
                    <div class="text-xl font-bold text-gray-700 mt-0.5"><?php echo e($metrics['pending']); ?></div>
                </div>
                <div class="bg-white p-3.5 rounded-xl border border-blue-200 bg-blue-50/30 shadow-sm text-center">
                    <div class="text-[11px] font-semibold text-blue-600 uppercase">চলমান (Working)</div>
                    <div class="text-xl font-bold text-blue-700 mt-0.5"><?php echo e($metrics['working']); ?></div>
                </div>
                <div class="bg-white p-3.5 rounded-xl border border-rose-200 bg-rose-50/30 shadow-sm text-center">
                    <div class="text-[11px] font-semibold text-rose-600 uppercase">রি-ওয়ার্কিং</div>
                    <div class="text-xl font-bold text-rose-700 mt-0.5"><?php echo e($metrics['reworking']); ?></div>
                </div>
                <div class="bg-white p-3.5 rounded-xl border border-amber-200 bg-amber-50/30 shadow-sm text-center">
                    <div class="text-[11px] font-semibold text-amber-600 uppercase">ইন রিভিউ (QA)</div>
                    <div class="text-xl font-bold text-amber-700 mt-0.5"><?php echo e($metrics['completed']); ?></div>
                </div>
                <div class="bg-white p-3.5 rounded-xl border border-purple-200 bg-purple-50/30 shadow-sm text-center">
                    <div class="text-[11px] font-semibold text-purple-600 uppercase">কিউএ পাস</div>
                    <div class="text-xl font-bold text-purple-700 mt-0.5"><?php echo e($metrics['checked']); ?></div>
                </div>
                <div class="bg-white p-3.5 rounded-xl border border-emerald-200 bg-emerald-50/30 shadow-sm text-center">
                    <div class="text-[11px] font-semibold text-emerald-600 uppercase">ডেলিভার্ড</div>
                    <div class="text-xl font-bold text-emerald-700 mt-0.5"><?php echo e($metrics['delivered']); ?></div>
                </div>
            </div>

            <!-- Filters -->
            <div class="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm">
                <form method="GET" action="<?php echo e(route('tasks.index')); ?>" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 items-end">
                    <div class="lg:col-span-2">
                        <label class="block text-xs font-medium text-gray-700 mb-1">অনুসন্ধান</label>
                        <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="টাস্ক কোড, নাম, প্রজেক্ট..."
                            class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                    </div>

                    <div>
                        <label class="block text-xs font-medium text-gray-700 mb-1">প্রজেক্ট</label>
                        <select name="project_id" class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                            <option value="">সকল প্রজেক্ট</option>
                            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($proj->id); ?>" <?php echo e(request('project_id') == $proj->id ? 'selected' : ''); ?>><?php echo e($proj->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs font-medium text-gray-700 mb-1">টিম মেম্বার</label>
                        <select name="assigned_to" class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                            <option value="">সকল মেম্বার</option>
                            <?php $__currentLoopData = $teamMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tm->id); ?>" <?php echo e(request('assigned_to') == $tm->id ? 'selected' : ''); ?>><?php echo e($tm->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs font-medium text-gray-700 mb-1">স্ট্যাটাস</label>
                        <select name="status" class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                            <option value="">সকল স্ট্যাটাস</option>
                            <?php $__currentLoopData = ['Pending', 'Working', 'Reworking', 'Completed', 'Checked', 'Delivered']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($st); ?>" <?php echo e(request('status') == $st ? 'selected' : ''); ?>><?php echo e($st); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="flex items-center gap-2">
                        <button type="submit" class="flex-1 py-2 px-4 bg-gray-900 text-white rounded-lg text-sm font-semibold hover:bg-gray-800 transition">
                            ফিল্টার
                        </button>
                        <?php if(request()->anyFilled(['search', 'project_id', 'assigned_to', 'status'])): ?>
                            <a href="<?php echo e(route('tasks.index')); ?>" class="py-2 px-3 bg-gray-100 text-gray-600 rounded-lg text-sm font-medium hover:bg-gray-200 transition">
                                রিসেট
                            </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <!-- Tasks Table -->
            <div class="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200 text-left text-sm">
                        <thead class="bg-gray-50 text-gray-500 font-semibold uppercase text-xs">
                            <tr>
                                <th class="py-3.5 px-4">টাস্ক</th>
                                <th class="py-3.5 px-4">প্রজেক্ট ও ক্লায়েন্ট</th>
                                <th class="py-3.5 px-4">অ্যাসাইন্ড কর্মী</th>
                                <th class="py-3.5 px-4">প্রাধান্য</th>
                                <th class="py-3.5 px-4">স্ট্যাটাস</th>
                                <th class="py-3.5 px-4">QA স্ট্যাটাস</th>
                                <th class="py-3.5 px-4">ডেডলাইন</th>
                                <th class="py-3.5 px-4 text-right">অ্যাকশন</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="hover:bg-gray-50/60 transition">
                                    <td class="py-3.5 px-4">
                                        <span class="font-mono text-xs font-bold text-indigo-700 bg-indigo-50 px-1.5 py-0.5 rounded"><?php echo e($task->task_code); ?></span>
                                        <a href="<?php echo e(route('tasks.show', $task)); ?>" class="font-bold text-gray-900 hover:text-indigo-600 block mt-1">
                                            <?php echo e($task->title); ?>

                                        </a>
                                        <span class="text-xs text-gray-400"><?php echo e($task->task_type); ?></span>
                                    </td>
                                    <td class="py-3.5 px-4">
                                        <a href="<?php echo e(route('projects.show', $task->project)); ?>" class="font-medium text-gray-800 hover:text-indigo-600 block">
                                            <?php echo e($task->project->name); ?>

                                        </a>
                                        <span class="text-xs text-gray-500"><?php echo e($task->project->customer?->name); ?></span>
                                    </td>
                                    <td class="py-3.5 px-4">
                                        <?php if($task->assignedUser): ?>
                                            <div class="flex items-center gap-2">
                                                <div class="w-6 h-6 rounded-full bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center text-xs">
                                                    <?php echo e(mb_substr($task->assignedUser->name, 0, 1)); ?>

                                                </div>
                                                <span class="text-xs text-gray-800 font-medium"><?php echo e($task->assignedUser->name); ?></span>
                                            </div>
                                        <?php else: ?>
                                            <span class="text-xs text-gray-400">অ্যাসাইন হয়নি</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-3.5 px-4">
                                        <?php
                                            $pClass = match($task->priority) {
                                                'Urgent' => 'bg-rose-100 text-rose-700',
                                                'High' => 'bg-amber-100 text-amber-700',
                                                'Medium' => 'bg-blue-100 text-blue-700',
                                                default => 'bg-gray-100 text-gray-700'
                                            };
                                        ?>
                                        <span class="px-2 py-0.5 rounded text-[11px] font-semibold <?php echo e($pClass); ?>">
                                            <?php echo e($task->priority); ?>

                                        </span>
                                    </td>
                                    <td class="py-3.5 px-4">
                                        <?php
                                            $taskStClass = match($task->status) {
                                                'Working' => 'bg-blue-50 text-blue-700 border-blue-200',
                                                'Reworking' => 'bg-rose-50 text-rose-700 border-rose-200',
                                                'Completed' => 'bg-amber-50 text-amber-700 border-amber-200',
                                                'Checked' => 'bg-purple-50 text-purple-700 border-purple-200',
                                                'Delivered' => 'bg-emerald-50 text-emerald-700 border-emerald-200',
                                                default => 'bg-gray-50 text-gray-700 border-gray-200'
                                            };
                                        ?>
                                        <span class="px-2 py-0.5 rounded-full text-xs font-semibold border <?php echo e($taskStClass); ?>">
                                            <?php echo e($task->status); ?>

                                        </span>
                                    </td>
                                    <td class="py-3.5 px-4">
                                        <?php if($task->qa_status === 'Passed'): ?>
                                            <span class="text-xs font-bold text-emerald-600">পাস (Passed)</span>
                                        <?php elseif($task->qa_status === 'Failed'): ?>
                                            <span class="text-xs font-bold text-rose-600">ত্রুটি (Failed)</span>
                                        <?php else: ?>
                                            <span class="text-xs text-gray-400">অপেক্ষমাণ</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-3.5 px-4 text-xs text-gray-500">
                                        <?php if($task->deadline): ?>
                                            <span class="<?php echo e($task->deadline->isPast() && !in_array($task->status, ['Checked', 'Delivered']) ? 'text-rose-600 font-bold' : ''); ?>">
                                                <?php echo e($task->deadline->format('d M, Y')); ?>

                                            </span>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-3.5 px-4 text-right">
                                        <a href="<?php echo e(route('tasks.show', $task)); ?>" class="inline-flex items-center px-2.5 py-1 bg-gray-100 hover:bg-indigo-50 hover:text-indigo-600 text-gray-700 rounded text-xs font-semibold transition">
                                            ডিটেইলস ও QA &rarr;
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" class="py-12 text-center text-gray-400">
                                        <svg class="w-12 h-12 mx-auto mb-3 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/></svg>
                                        <div class="text-base font-medium">কোনো টাস্ক পাওয়া যায়নি</div>
                                        <div class="text-sm mt-1">প্রজেক্ট ড্যাশবোর্ড থেকে নতুন টাস্ক যোগ করুন।</div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if($tasks->hasPages()): ?>
                    <div class="p-4 border-t border-gray-100">
                        <?php echo e($tasks->links()); ?>

                    </div>
                <?php endif; ?>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\AIUB\Language\Laravel\Projukti_Sheba\CRM\resources\views/tasks/index.blade.php ENDPATH**/ ?>