<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
                <h2 class="font-bold text-2xl text-gray-800 leading-tight flex items-center gap-2">
                    <svg class="w-7 h-7 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>
                    গ্রাহক তালিকা (Customer 360° Directory)
                </h2>
                <p class="text-sm text-gray-500 mt-1">স্থায়ী গ্রাহক ও কোম্পানির সম্পূর্ণ প্রোফাইল ও হিস্ট্রি</p>
            </div>
            <a href="<?php echo e(route('customers.create')); ?>" class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-lg font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700 shadow-sm transition">
                <svg class="w-4 h-4 me-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                নতুন গ্রাহক যোগ করুন
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">

            <!-- Alerts -->
            <?php if(session('success')): ?>
                <div class="p-4 bg-emerald-50 border-l-4 border-emerald-500 text-emerald-800 rounded-r-lg shadow-sm flex items-center justify-between">
                    <div class="flex items-center gap-2">
                        <svg class="w-5 h-5 text-emerald-600" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                        <span class="font-medium text-sm"><?php echo e(session('success')); ?></span>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Customer Metrics -->
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div class="bg-white p-4 rounded-xl border border-gray-200 shadow-sm flex items-center justify-between">
                    <div>
                        <div class="text-xs font-semibold text-gray-500 uppercase">মোট গ্রাহক</div>
                        <div class="text-2xl font-bold text-gray-900 mt-1"><?php echo e($metrics['total']); ?></div>
                    </div>
                    <div class="w-10 h-10 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                        👥
                    </div>
                </div>

                <div class="bg-white p-4 rounded-xl border border-gray-200 shadow-sm flex items-center justify-between">
                    <div>
                        <div class="text-xs font-semibold text-emerald-600 uppercase">সক্রিয় গ্রাহক (Active)</div>
                        <div class="text-2xl font-bold text-emerald-700 mt-1"><?php echo e($metrics['active']); ?></div>
                    </div>
                    <div class="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
                        ✓
                    </div>
                </div>

                <div class="bg-white p-4 rounded-xl border border-gray-200 shadow-sm flex items-center justify-between">
                    <div>
                        <div class="text-xs font-semibold text-gray-400 uppercase">নিষ্ক্রিয় (Inactive)</div>
                        <div class="text-2xl font-bold text-gray-600 mt-1"><?php echo e($metrics['inactive']); ?></div>
                    </div>
                    <div class="w-10 h-10 rounded-lg bg-gray-50 text-gray-500 flex items-center justify-center font-bold">
                        ✕
                    </div>
                </div>
            </div>

            <!-- Search Bar -->
            <div class="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm">
                <form method="GET" action="<?php echo e(route('customers.index')); ?>" class="flex flex-col sm:flex-row gap-3">
                    <div class="relative flex-1">
                        <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="নাম, কোম্পানি, ফোন বা কোড দিয়ে খুঁজুন..." class="w-full text-sm border-gray-300 rounded-lg pl-9 focus:ring-indigo-500 focus:border-indigo-500">
                        <svg class="w-4 h-4 text-gray-400 absolute left-3 top-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                    </div>

                    <div class="flex items-center gap-2">
                        <select name="status" class="text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                            <option value="">সকল স্ট্যাটাস</option>
                            <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>সক্রিয়</option>
                            <option value="inactive" <?php echo e(request('status') == 'inactive' ? 'selected' : ''); ?>>নিষ্ক্রিয়</option>
                        </select>

                        <button type="submit" class="px-5 py-2.5 bg-gray-900 text-white rounded-lg text-sm font-semibold hover:bg-gray-800 transition">
                            খুঁজুন
                        </button>
                    </div>
                </form>
            </div>

            <!-- Customer Table -->
            <div class="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200 text-left text-sm">
                        <thead class="bg-gray-50 text-gray-500 font-semibold uppercase text-xs">
                            <tr>
                                <th class="py-3.5 px-4">গ্রাহক কোড ও নাম</th>
                                <th class="py-3.5 px-4">প্রতিষ্ঠান / ব্যবসা</th>
                                <th class="py-3.5 px-4">যোগাযোগ (Phone / WA)</th>
                                <th class="py-3.5 px-4 text-center">লিড সংখ্যা</th>
                                <th class="py-3.5 px-4 text-center">কোটেশন সংখ্যা</th>
                                <th class="py-3.5 px-4">স্ট্যাটাস</th>
                                <th class="py-3.5 px-4 text-right">অ্যাকশন</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="hover:bg-gray-50/60 transition">
                                    <td class="py-3.5 px-4">
                                        <a href="<?php echo e(route('customers.show', $customer)); ?>" class="font-bold text-indigo-600 hover:text-indigo-800">
                                            <?php echo e($customer->customer_code); ?>

                                        </a>
                                        <div class="font-medium text-gray-900"><?php echo e($customer->name); ?></div>
                                    </td>
                                    <td class="py-3.5 px-4 text-xs text-gray-700">
                                        <div class="font-semibold text-gray-900"><?php echo e($customer->company_name ?? 'ব্যক্তিগত'); ?></div>
                                        <div class="text-gray-400"><?php echo e($customer->business_type ?? '-'); ?></div>
                                    </td>
                                    <td class="py-3.5 px-4 text-xs">
                                        <div class="font-medium text-gray-900"><?php echo e($customer->phone); ?></div>
                                        <?php if($customer->whatsapp): ?>
                                            <a href="https://wa.me/<?php echo e($customer->normalized_whatsapp ? '88' . $customer->normalized_whatsapp : '88' . $customer->normalized_phone); ?>" target="_blank" class="text-emerald-600 hover:underline">
                                                WA: <?php echo e($customer->whatsapp); ?>

                                            </a>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-3.5 px-4 text-center font-bold text-gray-700">
                                        <?php echo e($customer->leads_count); ?>

                                    </td>
                                    <td class="py-3.5 px-4 text-center font-bold text-indigo-600">
                                        <?php echo e($customer->quotations_count); ?>

                                    </td>
                                    <td class="py-3.5 px-4">
                                        <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold <?php echo e($customer->status === 'active' ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-100 text-gray-700'); ?>">
                                            <?php echo e($customer->status === 'active' ? 'Active' : 'Inactive'); ?>

                                        </span>
                                    </td>
                                    <td class="py-3.5 px-4 text-right">
                                        <a href="<?php echo e(route('customers.show', $customer)); ?>" class="inline-flex items-center gap-1 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 px-3 py-1.5 rounded-lg transition">
                                            360° প্রোফাইল &rarr;
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center py-10 text-gray-400 text-xs">
                                        কোন গ্রাহক পাওয়া যায়নি।
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if($customers->hasPages()): ?>
                    <div class="px-6 py-4 border-t border-gray-100 bg-gray-50">
                        <?php echo e($customers->links()); ?>

                    </div>
                <?php endif; ?>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\AIUB\Language\Laravel\Projukti_Sheba\CRM\resources\views/customers/index.blade.php ENDPATH**/ ?>