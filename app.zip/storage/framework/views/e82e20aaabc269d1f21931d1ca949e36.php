<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between">
            <div>
                <h2 class="font-bold text-2xl text-gray-800 leading-tight flex items-center gap-2">
                    <a href="<?php echo e(route('quotations.index')); ?>" class="text-gray-400 hover:text-gray-600 transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
                    </a>
                    নতুন কোটেশন তৈরি (New Quotation)
                </h2>
                <p class="text-sm text-gray-500 mt-0.5">সার্ভিস ও আইটেমভিত্তিক বিস্তারিত প্রস্তাবনা ও খরচ নির্ধারণ করুন</p>
            </div>
            <a href="<?php echo e(route('quotations.index')); ?>" class="text-sm font-medium text-gray-600 hover:text-gray-900 bg-white px-3.5 py-2 border border-gray-300 rounded-lg shadow-sm">
                তালিকায় ফিরে যান
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">

            <form method="POST" action="<?php echo e(route('quotations.store')); ?>" class="space-y-6">
                <?php echo csrf_field(); ?>

                <!-- Header Information -->
                <div class="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-4">
                    <h3 class="text-base font-bold text-gray-900 border-b pb-3">কোটেশন সাধারণ তথ্য</h3>

                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                        <!-- Select Lead or Customer -->
                        <div class="sm:col-span-2">
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">ক্লায়েন্ট / লিড নির্বাচন করুন <span class="text-rose-500">*</span></label>
                            <select name="lead_id" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                                <option value="">লিড নির্বাচন করুন...</option>
                                <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($l->id); ?>" <?php echo e((old('lead_id') == $l->id || ($preselectedLead && $preselectedLead->id == $l->id)) ? 'selected' : ''); ?>>
                                        <?php echo e($l->lead_code); ?> - <?php echo e($l->name); ?> (<?php echo e($l->phone); ?>)
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Quotation Date -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">কোটেশনের তারিখ <span class="text-rose-500">*</span></label>
                            <input type="date" name="quotation_date" value="<?php echo e(old('quotation_date', date('Y-m-d'))); ?>" required class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                        </div>

                        <!-- Valid Until -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">মেয়াদ উত্তীর্ণের তারিখ</label>
                            <input type="date" name="valid_until" value="<?php echo e(old('valid_until', date('Y-m-d', strtotime('+15 days')))); ?>" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                        </div>

                        <!-- Status -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">স্ট্যাটাস</label>
                            <select name="status" class="w-full text-sm border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                                <?php $__currentLoopData = ['Draft', 'Sent', 'Negotiation', 'Accepted', 'Rejected']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($st); ?>" <?php echo e(old('status') == $st ? 'selected' : ''); ?>><?php echo e($st); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Line Items Table -->
                <div class="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-4">
                    <div class="flex items-center justify-between border-b pb-3">
                        <h3 class="text-base font-bold text-gray-900">আইটেম ও সার্ভিস তালিকা</h3>
                        <button type="button" id="add-item-btn" class="px-3 py-1.5 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 font-semibold rounded-lg text-xs transition flex items-center gap-1">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                            আইটেম যোগ করুন
                        </button>
                    </div>

                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200 text-left text-xs" id="items-table">
                            <thead class="bg-gray-50 text-gray-600 font-semibold uppercase">
                                <tr>
                                    <th class="py-2.5 px-3 w-1/4">ক্যাটাগরি</th>
                                    <th class="py-2.5 px-3 w-2/5">বিবরণ / স্পেসিফিকেশন</th>
                                    <th class="py-2.5 px-3 w-24">পরিমাণ (Qty)</th>
                                    <th class="py-2.5 px-3 w-32">দর (Unit Price ৳)</th>
                                    <th class="py-2.5 px-3 w-32">মোট (Total ৳)</th>
                                    <th class="py-2.5 px-2 w-10"></th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100" id="items-body">
                                <tr class="item-row">
                                    <td class="p-2">
                                        <select name="items[0][service_category]" class="w-full text-xs border-gray-300 rounded-md">
                                            <?php $__currentLoopData = $serviceCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($cat); ?>"><?php echo e($cat); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </td>
                                    <td class="p-2">
                                        <input type="text" name="items[0][description]" required placeholder="সার্ভিস বা কাজের বিবরণ..." class="w-full text-xs border-gray-300 rounded-md">
                                    </td>
                                    <td class="p-2">
                                        <input type="number" step="0.01" name="items[0][quantity]" value="1" min="0.01" required class="qty-input w-full text-xs border-gray-300 rounded-md text-center">
                                    </td>
                                    <td class="p-2">
                                        <input type="number" step="0.01" name="items[0][unit_price]" value="0" min="0" required class="price-input w-full text-xs border-gray-300 rounded-md text-right">
                                    </td>
                                    <td class="p-2">
                                        <input type="text" readonly value="0.00" class="row-total w-full text-xs bg-gray-50 border-gray-200 rounded-md font-bold text-right text-gray-800">
                                    </td>
                                    <td class="p-2 text-center">
                                        <button type="button" class="remove-row-btn text-gray-400 hover:text-rose-600 transition">
                                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <!-- Totals Calculation Box -->
                    <div class="pt-4 border-t flex flex-col sm:flex-row justify-between gap-6">
                        <div class="flex-1 space-y-3">
                            <div>
                                <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">পেমেন্ট শর্তাবলী</label>
                                <textarea name="payment_terms" rows="2" placeholder="উদা: ৫০% অগ্রিম, বাকি ৫০% কাজ ডেলিভারির সময়।" class="w-full text-xs border-gray-300 rounded-lg">৫০% অগ্রিম, ৫০% লাইভ ডেলিভারির পূর্বে প্রদানযোগ্য।</textarea>
                            </div>
                            <div>
                                <label class="block text-xs font-semibold text-gray-700 uppercase mb-1">ডেলিভারি ও অন্যান্য শর্ত</label>
                                <textarea name="delivery_terms" rows="2" placeholder="কাজের সময়সীমা ও ওয়ারেন্টি শর্ত..." class="w-full text-xs border-gray-300 rounded-lg">চুক্তি স্বাক্ষরের ৭-১০ কার্যদিবসের মধ্যে ডেলিভারি। ৩ মাসের ফ্রি টেকনিক্যাল সাপোর্ট অন্তর্ভুক্ত।</textarea>
                            </div>
                        </div>

                        <div class="w-full sm:w-80 bg-gray-50 p-4 rounded-xl border border-gray-200 space-y-2 text-xs">
                            <div class="flex justify-between items-center text-gray-600">
                                <span>সাবটোটাল (Subtotal):</span>
                                <span class="font-bold text-gray-900" id="subtotal-display">৳0.00</span>
                            </div>

                            <div class="flex justify-between items-center">
                                <span class="text-gray-600">ডিসকাউন্ট (Discount ৳):</span>
                                <input type="number" step="0.01" id="discount-input" name="discount_amount" value="0" class="w-24 text-xs border-gray-300 rounded p-1 text-right">
                            </div>

                            <div class="flex justify-between items-center">
                                <span class="text-gray-600">ট্যাক্স / ভ্যাট (Tax ৳):</span>
                                <input type="number" step="0.01" id="tax-input" name="tax_amount" value="0" class="w-24 text-xs border-gray-300 rounded p-1 text-right">
                            </div>

                            <div class="pt-2 border-t border-gray-200 flex justify-between items-center text-sm font-bold text-gray-900">
                                <span>সর্বমোট মূল্য (Total):</span>
                                <span class="text-indigo-700 text-base" id="grand-total-display">৳0.00</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Submit Button -->
                <div class="flex items-center justify-end gap-3">
                    <a href="<?php echo e(route('quotations.index')); ?>" class="px-5 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold rounded-lg text-sm transition">
                        বাতিল
                    </a>
                    <button type="submit" class="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-sm shadow-sm transition flex items-center gap-2">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                        কোটেশন তৈরি করুন
                    </button>
                </div>
            </form>

        </div>
    </div>

    <!-- Live Calculation Script -->
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            let rowIdx = 1;
            const categories = <?php echo json_encode($serviceCategories, 15, 512) ?>;

            function recalculate() {
                let subtotal = 0;
                document.querySelectorAll('.item-row').forEach(row => {
                    const qty = parseFloat(row.querySelector('.qty-input').value) || 0;
                    const price = parseFloat(row.querySelector('.price-input').value) || 0;
                    const rowTotal = qty * price;
                    row.querySelector('.row-total').value = rowTotal.toFixed(2);
                    subtotal += rowTotal;
                });

                const discount = parseFloat(document.getElementById('discount-input').value) || 0;
                const tax = parseFloat(document.getElementById('tax-input').value) || 0;
                const grandTotal = Math.max(0, subtotal - discount + tax);

                document.getElementById('subtotal-display').innerText = '৳' + subtotal.toLocaleString('en-US', { minimumFractionDigits: 2 });
                document.getElementById('grand-total-display').innerText = '৳' + grandTotal.toLocaleString('en-US', { minimumFractionDigits: 2 });
            }

            document.getElementById('items-body').addEventListener('input', function (e) {
                if (e.target.classList.contains('qty-input') || e.target.classList.contains('price-input')) {
                    recalculate();
                }
            });

            document.getElementById('discount-input').addEventListener('input', recalculate);
            document.getElementById('tax-input').addEventListener('input', recalculate);

            document.getElementById('add-item-btn').addEventListener('click', function () {
                const tbody = document.getElementById('items-body');
                const tr = document.createElement('tr');
                tr.className = 'item-row';

                let optionsHtml = '';
                categories.forEach(c => { optionsHtml += `<option value="${c}">${c}</option>`; });

                tr.innerHTML = `
                    <td class="p-2">
                        <select name="items[${rowIdx}][service_category]" class="w-full text-xs border-gray-300 rounded-md">
                            ${optionsHtml}
                        </select>
                    </td>
                    <td class="p-2">
                        <input type="text" name="items[${rowIdx}][description]" required placeholder="সার্ভিস বা কাজের বিবরণ..." class="w-full text-xs border-gray-300 rounded-md">
                    </td>
                    <td class="p-2">
                        <input type="number" step="0.01" name="items[${rowIdx}][quantity]" value="1" min="0.01" required class="qty-input w-full text-xs border-gray-300 rounded-md text-center">
                    </td>
                    <td class="p-2">
                        <input type="number" step="0.01" name="items[${rowIdx}][unit_price]" value="0" min="0" required class="price-input w-full text-xs border-gray-300 rounded-md text-right">
                    </td>
                    <td class="p-2">
                        <input type="text" readonly value="0.00" class="row-total w-full text-xs bg-gray-50 border-gray-200 rounded-md font-bold text-right text-gray-800">
                    </td>
                    <td class="p-2 text-center">
                        <button type="button" class="remove-row-btn text-gray-400 hover:text-rose-600 transition">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                        </button>
                    </td>
                `;

                tbody.appendChild(tr);
                rowIdx++;
            });

            document.getElementById('items-body').addEventListener('click', function (e) {
                const btn = e.target.closest('.remove-row-btn');
                if (btn) {
                    const rows = document.querySelectorAll('.item-row');
                    if (rows.length > 1) {
                        btn.closest('tr').remove();
                        recalculate();
                    } else {
                        alert('অন্তত একটি আইটেম রাখা আবশ্যক।');
                    }
                }
            });

            recalculate();
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\AIUB\Language\Laravel\Projukti_Sheba\CRM\resources\views/quotations/create.blade.php ENDPATH**/ ?>